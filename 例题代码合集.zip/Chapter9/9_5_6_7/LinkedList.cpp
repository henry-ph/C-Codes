//9_6.cpp
#include <iostream>
#include <cstdlib>
#include "LinkedList.h"
using namespace std;

